﻿
function validateFileNumber() {
    var fileNo = $('#FileNo').val();
    var regex = /^[A-Z]{3}\/[A-Z]{3}\/\d{7}\/\d{2}\/\d{2}$/;

    if (!regex.test(fileNo)) {
        $('#validationError').text('Invalid file number. Correct format is:"GEX/LCB/0977048/05/23"');
        return false;
    }

    $('#validationError').text('');
    return true;
}

function validateCountry() {
    var country = $('#countryList option:selected').val();
    if (country == null || country == "" || country == undefined || country == "none" || country == "--Select--") {
        $('#validationCountry').text('Please select country');
        return false;
    }

    $('#validationCountry').text('');
    return true;
}

function validateHBL() {
    var hbl = $('#HBLNo').val();
    if (hbl == null || hbl == "" || hbl == undefined) {
        $('#validationHBL').text('Please enter hbl');
        return false;
    }

    $('#validationHBL').text('');
    return true;
}


function validateContainer() {
    var containerNo = $('#Container').val();
    if (containerNo.length < 10 && containerNo.length != "" && containerNo.length != null && containerNo.length != undefined) {
        $('#validationContainer').text('Invalid container number. Correct format is:"ABCD123456"');
        $('#validationHBLContainer').text('Invalid container number. Correct format is:"ABCD123456"');
        return false;
    }
    else if (containerNo.length > 11 && containerNo.length != "" && containerNo.length != null && containerNo.length != undefined) {
        $('#validationContainer').text('Invalid container number. Correct format is:"ABCD123456"');
        $('#validationHBLContainer').text('Invalid container number. Correct format is:"ABCD123456"');
        return false;
    }
    else {
        $('#validationContainer').text('');
        $('#validationHBLContainer').text('');
        return true;
    }
    
}

function validateHBLFileNumber() {
    var fileNo = $('#HBLFileNo').val();
    if (fileNo != '') {
        var regex = /^[A-Z]{3}\/[A-Z]{3}\/\d{7}\/\d{2}\/\d{2}$/;

        if (!regex.test(fileNo)) {
            $('#validationHBLError').text('Invalid file number. Correct format is:"GEX/LCB/0977048/05/23"');
            return false;
        }

        $('#validationHBLError').text('');
        return true;
    }
    
}

//function validateContainer() {
//    var containerNo = $('#Container').val();
//    if (containerNo.length < 10 && containerNo.length != "" && containerNo.length != null && containerNo.length != undefined) {
//        $('#validationHBLContainer').text('Invalid container number. Correct format is:"ABCD123456"');
//        return false;
//    }
//    else if (containerNo.length > 11 && containerNo.length != "" && containerNo.length != null && containerNo.length != undefined) {
//        $('#validationHBLContainer').text('Invalid container number. Correct format is:"ABCD123456"');
//        return false;
//    }
//    else {
//        $('#validationHBLContainer').text('');
//        return true;
//    }
//}
function validateComment() {
    var HBLStatus = $('#HBLStatus option:selected').text();
    var comment = $('#Comment').val();
    if (HBLStatus != "Completed" && comment.length == "" || HBLStatus != "Completed" && comment.length == null) {
        $('#validationComment').text('Comment should be at least 10 characters long.');
        return false;
    }

    $('#validationComment').text('');
    return true;
}

function validateETD() {
    var ETD = $('#ETD').val();
    if (ETD == "" || ETD == null || ETD == undefined) {
        $('#validationETD').text('Please select ETD');
        return false;
    }

    $('#validationETD').text('');
    return true;
}

function validateETAPOD() {
    var ETAPOD = $('#ETAPOD').val();
    if (ETAPOD == "" || ETAPOD == null || ETAPOD == undefined) {
        $('#validationETAPOD').text('Please select ETAPOD');
        return false;
    }

    $('#validationETAPOD').text('');
    return true;
}

function validateETA() {
    var ETA = $('#ETA').val();
    if (ETA == "" || ETA == null || ETA == undefined) {
        $('#validationETA').text('Please select ETA');
        return false;
    }

    $('#validationETA').text('');
    return true;
}

function validateSICutOff() {
    var DraftCutOff = $('#DraftCutOff').val();
    if (DraftCutOff == "" || DraftCutOff == null || DraftCutOff == undefined) {
        $('#validationSICutOff').text('Please select SI Cut Off');
        return false;
    }

    $('#validationSICutOff').text('');
    return true;
}

function validateATD() {
    var ATD = $('#ATD').val();
    if (ATD == "" || ATD == null || ATD == undefined) {
        $('#validationATD').text('Please select ATD');
        return false;
    }

    $('#validationATD').text('');
    return true;
}
function validateATD() {
    var ATD = $('#ATD').val();
    if (ATD == "" || ATD == null || ATD == undefined) {
        $('#validationATD').text('Please select ATD');
        return false;
    }

    $('#validationATD').text('');
    return true;
}