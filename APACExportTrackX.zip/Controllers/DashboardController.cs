﻿using ClosedXML.Excel;
using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;

namespace APACExportTrackX.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        ApplicationDBContext _context;
        public DashboardController(ApplicationDBContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Index()
        {
            ViewBag.StatusMaster = _context.StatusMaster.ToList();
            ViewBag.ApplicationUser = _context.Users.ToList();
            ViewBag.ActivityMaster = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.IsActive == true).OrderBy(x => x.FileSequence).ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewData["Country"] = _context.CountryMaster.ToList();
            return View();
        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpPost]
        public IActionResult GetFiles(string activity, string Country, string fileNumber, string search, string status)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");


            List<FileDashModel> fileDashModel = new List<FileDashModel>();

            var data = _context.ContainerMaster.Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            {
                Id = x.FileMaster.Id,
                ContainerId = x.Id,
                EnterDate = x.FileMaster.EnterDate,
                FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                POD = x.FileMaster.CountryMaster.CountryName,
                SICutOff = x.SICutOff,
                ShippingLine = x.FileMaster.ShippingLine,
                FileContact = x.FileMaster.FileContact,
                UserId = x.FileActivityLogs.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).FirstOrDefault().ApplicationUser.UserName,
                ActivityId = x.FileActivityLogs.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).FirstOrDefault().Activity.NameOfActivity ?? "",
                StatusId = x.FileActivityLogs.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).FirstOrDefault().Status.Status ?? "UnAllocated",
                ContainerNo = x.ContainerNo,
                TotalHBL = x.FileMaster.TotalBL,
                Comment = x.FileActivityLogs.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).FirstOrDefault().Comment ?? "",
                CarrierRequest = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Carrier Request")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                TallySheetChecking = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Tally Sheet")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                SIToCarrier = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "SI To Carrier")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                MBLReview = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "MBL Review")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                Invoice = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Invoices To POD Agent")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                FinalBL = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                PreAlert = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Pre-Alert")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                Permit = x.FileActivityLogs
                    .Where(y => y.Activity.NameOfActivity == "Permit")
                    .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate)
                    .FirstOrDefault().Status.Status ?? "UnAllocated",
                EndDate = x.FileActivityLogs.OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate).ThenBy(y => y.EndDate).FirstOrDefault().EndDate
            }).ToList();


            IQueryable<FileDashModel> SortedData = data.AsQueryable();

            if (!string.IsNullOrEmpty(activity) && activity != "none" && activity != "--Select--" && activity != "-- Select Activities --")
            {
                switch (activity)
                {
                    case "SI To Carrier":
                        if(!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "SI To Carrier" && x.StatusId == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Carrier Request" && x.StatusId == "Completed");
                        }
                        break;
                    case "Final BL To Invoices Customer":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Final BL To Invoices Customer" && x.StatusId == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "SI To Carrier" && x.StatusId == "Completed");
                        }
                        break;
                    case "Pre-Alert":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Pre-Alert" && x.StatusId == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Final BL To Invoices Customer" && x.StatusId == "Completed");
                        }
                        break;
                    case "Permit":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Permit" && x.StatusId == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Pre-Alert" && x.StatusId == "Completed");
                        }
                        break;
                    case "Invoices To POD Agent":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Invoices To POD Agent" && x.StatusId == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Permit" && x.StatusId == "Completed");
                        }
                        break;
                    case "Carrier Request":
                        if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Carrier Request" && x.StatusId == status);
                        }
                        else
                        {
                            SortedData = SortedData.Where(x => x.ActivityId == "Carrier Request" && x.StatusId != "Completed");
                        }
                        break;
                    default:
                        if (status == "--Select--")
                        {
                            status = "UnAllocated";
                        }                      
                        SortedData = SortedData.Where(x => (x.ActivityId != activity.Trim() && x.StatusId == status) || (x.ActivityId == activity.Trim() && x.StatusId != "Completed"));
                        break;
                }
            }

            if (!string.IsNullOrEmpty(Country) && Country != "none" && Country != "--Select--")
            {
                SortedData = SortedData.Where(x => x.POD == Country.Trim());
            }

            if (!string.IsNullOrEmpty(fileNumber))
            {
                SortedData = SortedData.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }

            if (search == "WIP" || search == "Completed" || search == "Pending" || search == "Query" ||
                search == "Received" || search == "UnAllocated" || search == "etd10" || search == "etd12" || search == "etd18" || search == "si")
            {
                switch (search)
                {
                    case "etd10":
                        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.AddDays(-10) <= DateTime.Now && x.StatusId != "Completed");
                        break;
                    case "etd12":
                        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.AddDays(-10) > DateTime.Now && x.ETD.Value.AddDays(-12) <= DateTime.Now && x.StatusId != "Completed");
                        break;
                    case "etd18":
                        SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.AddDays(-12) > DateTime.Now && x.StatusId != "Completed");
                        break;
                    case "Received":
                        break; // No filtering needed
                    case "UnAllocated":
                        SortedData = SortedData.Where(x => x.UserId == null);
                        break;
                    case "si":
                        SortedData = SortedData.Where(x => x.StatusId != "Completed" && x.SICutOff != null && x.SICutOff.Value.Date == DateTime.Today);
                        break;
                    default:
                        SortedData = SortedData.Where(x => x.StatusId == search && (x.CarrierRequest == search || x.TallySheetChecking == search || x.SIToCarrier == search || x.MBLReview == search || x.Invoice == search || x.FinalBL == search || x.PreAlert == search || x.Permit == search) && x.EndDate != null && x.EndDate.Value.Date == DateTime.Today);
                        break;
                }
            }

            if (!string.IsNullOrEmpty(status) && status != "none" && status != "--Select--" && status != "-- Select Status --")
            {
                if (status == "UnAllocated")
                {
                    SortedData = SortedData.Where(x => x.StatusId == "UnAllocated" && x.UserId == null);
                }
                else
                {
                    SortedData = SortedData.Where(x => x.StatusId == status.Trim());
                }
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection);
            }
            else
            {
                sortColumn = "enterDate";
                sortColumnDirection = "desc";
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection);
            }

            SortedData = SortedData.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize);

            var returnObj = new
            {
                draw = draw,
                recordsTotal = data.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.ToList()
            };

            return Json(returnObj);
        }

        [HttpGet]
        public IActionResult GetHblData(string id)
        {
            var hbl = _context.HBLMaster.Where(x => x.ContainerId == id).ToList();

            var sm = _context.StatusMaster.ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerId == id).Select(x => new FileDashModel
            {
                ContainerId = x.ContainerId,
                ActivityId = x.Activity.NameOfActivity,
                StatusId = x.Status.Status,
                UserId = x.ApplicationUser.UserName,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                LBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count(),
                TBL = _context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count(),
                TotalHBL = (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && y.HBLNumber.StartsWith("SIN")).Count()) + (_context.HBLMaster.Where(y => y.ContainerId == x.ContainerId && !y.HBLNumber.StartsWith("SIN")).Count())
            }).ToList();
            return Json(new { fm, hbl, sm });
        }

        [HttpGet]
        public IActionResult GetHblDataGetHblData(string id)
        {
            var hbl = _context.HBLMaster.Where(x => x.ContainerId == id).ToList();

            var sm = _context.StatusMaster.ToList();

            var fm = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.ContainerMaster.Id == id).ToList();

            return Json(new { fm, hbl, sm });
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string id)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.HBLId == id).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }


        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult GetDashboardCount()
        {
            var fileActivityLogs = _context.FileActivityLog.Include(x => x.ContainerMaster).Include(x => x.Status).Include(x => x.ApplicationUser).ToList();

            var data = _context.ContainerMaster.Include(x => x.FileMaster).Include(x => x.FileActivityLogs).ThenInclude(x => x.ApplicationUser).Select(x => new FileDashModel
            {
                Id = x.FileMaster.Id,
                ContainerId = x.Id,
                EnterDate = x.FileMaster.EnterDate,
                FileNumber = x.FileMaster.FileNumber.Substring(0, x.FileMaster.FileNumber.Length - 6),
                POD = x.FileMaster.CountryMaster.CountryName,
                SICutOff = x.SICutOff,
                ShippingLine = x.FileMaster.ShippingLine,
                FileContact = x.FileMaster.FileContact,
                UserId = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id)
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.ApplicationUser.UserName)
                        .FirstOrDefault(),
                StatusId = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id)
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                ActivityId = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id)
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Activity.NameOfActivity)
                        .FirstOrDefault(),
                ContainerNo = x.ContainerNo,
                TotalHBL = x.FileMaster.TotalBL,
                Comment = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id)
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Comment)
                        .FirstOrDefault() ?? "",
                CarrierRequest = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Carrier Request")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                TallySheetChecking = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Tally Sheet")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                SIToCarrier = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "SI To Carrier")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                MBLReview = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "MBL Review")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                Invoice = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Invoices To POD Agent")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                FinalBL = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Final BL To Invoices Customer")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                PreAlert = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Pre-Alert")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                Permit = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id && y.Activity.NameOfActivity == "Permit")
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.Status.Status)
                        .FirstOrDefault() ?? "UnAllocated",
                EndDate = x.FileActivityLogs
                        .Where(y => y.ContainerId == x.Id)
                        .OrderByDescending(y => y.ContainerMaster.FileMaster.EnterDate)
                        .Select(y => y.EndDate)
                        .FirstOrDefault(),
            }).ToList();

            var currentDate = DateTime.UtcNow.Date;

            DashboardProdcount dp = new DashboardProdcount
            {
                Received = data.Count(),
                Pending = data.Count(x => x.StatusId == "Pending" && (x.CarrierRequest == "Pending" || x.TallySheetChecking == "Pending" || x.SIToCarrier == "Pending" || x.MBLReview == "Pending" || x.Invoice == "Pending" || x.FinalBL == "Pending" || x.PreAlert == "Pending" || x.Permit == "Pending") && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                WIP = data.Count(x => x.StatusId == "WIP" && (x.CarrierRequest == "WIP" || x.TallySheetChecking == "WIP" || x.SIToCarrier == "WIP" || x.MBLReview == "WIP" || x.Invoice == "WIP" || x.FinalBL == "WIP" || x.PreAlert == "WIP" || x.Permit == "WIP") && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                Query = data.Count(x => x.StatusId == "Query" && (x.CarrierRequest == "Query" || x.TallySheetChecking == "Query" || x.SIToCarrier == "Query" || x.MBLReview == "Query" || x.Invoice == "Query" || x.FinalBL == "Query" || x.PreAlert == "Query" || x.Permit == "Query") && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                Completed = data.Count(x => x.StatusId == "Completed" && (x.CarrierRequest == "Completed" || x.TallySheetChecking == "Completed" || x.SIToCarrier == "Completed" || x.MBLReview == "Completed" || x.Invoice == "Completed" || x.FinalBL == "Completed" || x.PreAlert == "Completed" || x.Permit == "Completed") && x.EndDate != null && x.EndDate.Value.Date == currentDate),
                UnAllocated = data.Count(x => x.StatusId == "UnAllocated" && x.UserId == null),
                siCutOff = data.Count(x => x.SICutOff != null && x.SICutOff.Value.Date == currentDate && x.StatusId != "Completed"),
            };

            return Json(dp);

        }

        [Authorize(Roles = "Supervisor,Manager")]
        public ActionResult Report()
        {

            return View();
        }

        //List to Database convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //Get UserCount
        public ActionResult GetCountofUser()
        {

            return View();
        }

        [HttpGet]
        public IActionResult GetHblActivityDataList(string hblId)
        {
            ViewData["hblActivityList"] = _context.HBLActivityLog.Include(x => x.Hbl).Where(x => x.HBLId == hblId).Select(x => new HBLActivityLogsListViewModel
            {
                Id = x.Id,
                HBLNumber = x.Hbl.HBLNumber == null ? "" : x.Hbl.HBLNumber,
                Activity = x.Activity.NameOfActivity,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                Status = x.Status.Status,
                Comment = x.Comment == null ? "" : x.Comment,
                User = x.ApplicationUser.CitrixId == null ? "" : x.ApplicationUser.CitrixId
            }).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult GetHblActivityDataList(string hblno, string hbl)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.ApplicationUser).Where(x => x.Hbl.HBLNumber == hblno).ToList();
            List<HBLActivityLogsListViewModel> hblActivityLog = new List<HBLActivityLogsListViewModel>();
            foreach (var item in hblact)
            {
                hblActivityLog.Add(new HBLActivityLogsListViewModel
                {
                    Id = item.Id,
                    HBLNumber = hblno == null ? "" : hblno,
                    Activity = item.Activity.NameOfActivity == null ? "" : item.Activity.NameOfActivity,
                    StartDate = item.StartDate,
                    EndDate = item.EndDate,
                    Status = item.Status.Status,
                    User = item.ApplicationUser.CitrixId,
                    Comment = item.Comment,

                });
            }
            return Json(hblActivityLog);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult FileAllocation(string[] fileNumbers, string activity, string user, string status)
        {
            try
            {
                if (fileNumbers.Length == 0)
                {
                    return Json("Please select file checkbox");
                }
                else if (activity == null)
                {
                    return Json("Please select activities");
                }
                else if (user == null)
                {
                    return Json("Please select user");
                }
                //else if (status == null)
                //{
                //    return Json("Please select Status");
                //}
                else
                {
                    var compstatusId = _context.StatusMaster.Where(x => x.Status == "Completed").Select(x => x.Id).FirstOrDefault();
                    var statusId = _context.StatusMaster.Where(x => x.Status == "Pending").Select(x => x.Id).FirstOrDefault();
                    var completedwithquery = _context.StatusMaster.Where(x => x.Status == "Completed With Query").Select(x => x.Id).FirstOrDefault();
                    var carrierRequest = _context.ActivityMaster.Where(x => x.NameOfActivity == "Carrier Request").Select(x => x.Id).FirstOrDefault();
                    var tblProcessing = _context.ActivityMaster.Where(x => x.NameOfActivity == "TBL Processing").Select(x => x.Id).FirstOrDefault();
                    var siToCarrier = _context.ActivityMaster.Where(x => x.NameOfActivity == "SI To Carrier").Select(x => x.Id).FirstOrDefault();
                    var tallySheet = _context.ActivityMaster.Where(x => x.NameOfActivity == "Tally Sheet").Select(x => x.Id).FirstOrDefault();
                    var mblReview = _context.ActivityMaster.Where(x => x.NameOfActivity == "MBL Review").Select(x => x.Id).FirstOrDefault();
                    var finalBL = _context.ActivityMaster.Where(x => x.NameOfActivity == "Final BL").Select(x => x.Id).FirstOrDefault();
                    var preAlert = _context.ActivityMaster.Where(x => x.NameOfActivity == "Pre-Alert").Select(x => x.Id).FirstOrDefault();
                    var permit = _context.ActivityMaster.Where(x => x.NameOfActivity == "Permit").Select(x => x.Id).FirstOrDefault();
                    var invoices = _context.ActivityMaster.Where(x => x.NameOfActivity == "Invoices To POD Agent").Select(x => x.Id).FirstOrDefault();
                    string msg = "";
                    foreach (string fileid in fileNumbers)
                    {
                        var fileactivity = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == activity).FirstOrDefault();
                        if (fileactivity != null)
                        {
                            if (fileactivity.StatusId == compstatusId)
                            {
                                return Json("File activity status is completed so does not allocate");
                            }
                            else if (fileactivity.ActivityId == siToCarrier)
                            {
                                if (fileactivity.ActivityId == carrierRequest && fileactivity.StatusId == compstatusId)
                                {

                                    if (fileactivity.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivity.UserId = user;
                                        fileactivity.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivity);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivity.ActivityId == carrierRequest && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Carrier Request activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == finalBL)
                            {
                                if ((fileactivity.ActivityId == siToCarrier && fileactivity.StatusId == compstatusId))
                                {
                                    if (fileactivity.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivity.UserId = user;
                                        fileactivity.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivity);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivity.ActivityId == siToCarrier && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected SI To Carrier activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == preAlert)
                            {
                                if (fileactivity.ActivityId == finalBL && fileactivity.StatusId == compstatusId)
                                {
                                    if (fileactivity.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivity.UserId = user;
                                        fileactivity.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivity);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivity.ActivityId == finalBL && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Final BL activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == permit)
                            {
                                if (fileactivity.ActivityId == preAlert && fileactivity.StatusId == compstatusId)
                                {
                                    if (fileactivity.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivity.UserId = user;
                                        fileactivity.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivity);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivity.ActivityId == preAlert && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Pre-Alert activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else if (fileactivity.ActivityId == invoices)
                            {
                                if (fileactivity.ActivityId == permit && fileactivity.StatusId == compstatusId)
                                {
                                    if (fileactivity.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivity.UserId = user;
                                        fileactivity.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivity);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivity.ActivityId == permit && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Invoices To POD Agent activity.");
                                }
                                else
                                {
                                    return Json("File Allocated to selected user.");
                                }
                            }
                            else
                            {
                                if (fileactivity.UserId == user)
                                {
                                    return Json("Same User");
                                }
                                else
                                {
                                    fileactivity.UserId = user;
                                    fileactivity.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }

                            }
                        }
                        else
                        {
                            FileActivityLog fileActivitylog = new FileActivityLog
                            {
                                ContainerId = fileid,
                                ActivityId = activity,
                                StatusId = statusId,
                                UserId = user,
                                Comment = null,
                                StartDate = null,
                                EndDate = null,
                            };
                            _context.FileActivityLog.Add(fileActivitylog);
                            _context.SaveChanges();
                            var fileactivityList = _context.FileActivityLog.Where(x => x.ContainerId == fileid && x.ActivityId == activity).FirstOrDefault();
                            if (fileactivityList.StatusId == compstatusId)
                            {
                                return Json("File activity status is completed so does not allocate");
                            }
                            else if (fileactivityList.ActivityId == siToCarrier)
                            {
                                if (fileactivityList.ActivityId == carrierRequest && fileactivityList.StatusId == compstatusId)
                                {
                                    if (fileactivityList.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivityList.UserId = user;
                                        fileactivityList.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivityList);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivityList.ActivityId == carrierRequest && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Carrier Request activity.");
                                }
                                else
                                {

                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == finalBL)
                            {
                                if ((fileactivityList.ActivityId == siToCarrier && fileactivityList.StatusId == compstatusId))
                                {
                                    if (fileactivityList.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivityList.UserId = user;
                                        fileactivityList.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivityList);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivityList.ActivityId == siToCarrier && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected SI To Carrier activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }

                            }
                            else if (fileactivityList.ActivityId == preAlert)
                            {
                                if (fileactivityList.ActivityId == finalBL && fileactivityList.StatusId == compstatusId)
                                {
                                    if (fileactivityList.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivityList.UserId = user;
                                        fileactivityList.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivityList);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivityList.ActivityId == finalBL && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Final BL activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == permit)
                            {
                                if (fileactivityList.ActivityId == preAlert && fileactivityList.StatusId == compstatusId)
                                {
                                    if (fileactivityList.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivityList.UserId = user;
                                        fileactivityList.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivityList);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivityList.ActivityId == preAlert && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Pre-Alert activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else if (fileactivityList.ActivityId == invoices)
                            {
                                if (fileactivityList.ActivityId == permit && fileactivityList.StatusId == compstatusId)
                                {
                                    if (fileactivityList.UserId == user)
                                    {
                                        return Json("Same User");
                                    }
                                    else
                                    {
                                        fileactivityList.UserId = user;
                                        fileactivityList.StatusId = statusId;
                                        _context.FileActivityLog.Update(fileactivityList);
                                        _context.SaveChanges();
                                    }
                                }
                                else if (fileactivityList.ActivityId == permit && fileactivity.StatusId != compstatusId)
                                {
                                    return Json("Please complete selected Invoices To POD Agent activity.");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                            else
                            {

                                if (fileactivityList.UserId == user)
                                {
                                    return Json("Same User");
                                }
                                else
                                {
                                    fileactivityList.UserId = user;
                                    fileactivityList.StatusId = statusId;
                                    _context.FileActivityLog.Update(fileactivityList);
                                    _context.SaveChanges();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }
            _context.SaveChanges();
            return Json("Success");

        }
    }
}
