﻿using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace APACExportTrackX.Controllers
{
	public class CountryController : Controller
	{
		private readonly ApplicationDBContext _context;

		public CountryController(ApplicationDBContext context)
		{
			_context = context;
		}

		// GET: Country
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Index()
		{
			ViewData["Country"] = _context.CountryMaster.ToList();
			return View(await _context.CountryMaster.ToListAsync());
		}

		// GET: Country/Details/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Details(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var country = await _context.CountryMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (country == null)
			{
				return NotFound();
			}

			return View(country);
		}

		// GET: Country/Create
		[Authorize(Roles = "Supervisor,Manager")]
		public IActionResult Create()
		{
			return View();
		}

		// POST: Country/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Create([Bind("Id,CountryName")] CountryMaster country)
		{
			bool success = false;
			var result = new { success = success , message = "Error while processing the request." };
			var countryMaster = _context.CountryMaster.Where(x => x.CountryName == country.CountryName).FirstOrDefault();

			if (ModelState.IsValid)
			{
				if (countryMaster == null)
				{
					_context.Add(country);
					await _context.SaveChangesAsync();
					success = true;
				}
				else
				{
					success = false;
				}
			}
			if (success == true)
			{
				result = new { success = success, message = "success" };
			}
			else if (countryMaster != null && success == false)
			{
				result = new { success = success, message = "duplicate" };
			}
			else
			{
				result = new { success = success, message = "error" };
			}
			return Json(result);
		}

		// GET: Country/Edit/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Edit(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var country = await _context.CountryMaster.FindAsync(id);
			if (country == null)
			{
				return NotFound();
			}
			return View(country);
		}

		// POST: Country/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Edit(string id, [Bind("Id,CountryName")] CountryMaster country)
		{
			bool success = false;
			var result = new { success = success, message = "Error while processing the request." };
			if (id != country.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(country);
					await _context.SaveChangesAsync();
					success = true;
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!CountryExists(country.Id))
					{
						return NotFound();
						success = false;
					}
					else
					{
						throw;
						success = false;
					}
				}
				//return RedirectToAction(nameof(Index));
				if (success == true)
				{
					result = new { success = success, message = "success" };
				}
				else
				{
					result = new { success = success, message = "error" };
				}
			}
			return Json(result);
		}

		// GET: Country/Delete/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Delete(string? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var country = await _context.CountryMaster.FirstOrDefaultAsync(m => m.Id == id); 
			if (country == null)
			{
				return NotFound();
			}

			return View(country);
		}

		// POST: Country/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> DeleteConfirmed(string id)
		{
			var country = await _context.CountryMaster.FindAsync(id);
			_context.CountryMaster.Remove(country);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		private bool CountryExists(string id)
		{
			return _context.CountryMaster.Any(e => e.Id == id);
		}
	}
}


